import { Component, ViewChild } from '@angular/core';
import { NgForm, UntypedFormBuilder, UntypedFormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage {
  @ViewChild('msgForm') msgForm: NgForm | undefined
  msgFormGrp!: UntypedFormGroup

  messages: Message[] = []

  isLoading: boolean = false

  constructor(
    private _formBuilder: UntypedFormBuilder
  ) {
    this.msgFormGrp = _formBuilder.group({
      msg: ['', [Validators.required, Validators.minLength(2)]]
    })
  }

  ngOnInit() {
    this.dummyMessages()
  }

  dummyMessages() {
    const msgs = [
      {
        user: 'system',
        message: 'Hello, how can I help you?',
        message_id: '1',
        date: '25 Apr 2024'
      },
      {
        user: 'user',
        message: 'What is the impact of covid-19 on the financials of McKesson corporation?',
        message_id: '2',
        date: '25 Apr 2024'
      },
      {
        user: 'system',
        message: "McKesson Corporation has seen an overall positive financial impact from the COVID-19 pandemic. This includes higher revenues from retail national account customers and market growth, increased sales of COVID-19 tests, and contributions from kitting and distribution of ancillary supplies for the U.S. government's COVID-19 vaccine program. Additionally, McKesson has used cash to support its international COVID-19 vaccine donation mission and committed to donating certain PPE to charitable organizations to assist in COVID- 19 recovery efforts.",
        message_id: '3',
        date: '25 Apr 2024'
      },
      {
        user: 'user',
        message: 'What is the impact of covid-19 on the earnings per share of McKesson corporation?',
        message_id: '2',
        date: '25 Apr 2024'
      },
      {
        user: 'system',
        message: "McKesson Corporation has seen an increase in their earnings per share due to their involvement in the COVID-19 response efforts. This includes contributions from the distribution of COVID-19 vaccines, ancillary supply kits, and COVID-19 tests. In addition, McKesson's partnership with the U.S. government was expanded to support the U.S. government's international COVID-19 vaccine donation mission which has resulted in a contribution of $0.35 to $0.45 related to the U.S government's COVID- 19 vaccine distribution program and $0.75 to $0.95 related to kitting, storage, and distribution of ancillary supplies program and COVID-19 tests for fiscal 2023 Adjusted Earnings per Diluted Share guidance range of $23.95 -$24.65",
        message_id: '3',
        date: '25 Apr 2024'
      },
      {
        user: 'user',
        message: "What is the revenue fiscal year 2019 quarter fourth?",
        message_id: '2',
        date: '25 Apr 2024'
      },
      {
        user: 'system',
        message: "The revenue for the fourth quarter of fiscal year 2019 was $52.4 billion.",
        message_id: '3',
        date: '25 Apr 2024'
      },
      {
        user: 'user',
        message: "Compare revenue of McKesson corporation for fiscal year 2018 first quarter and revenue of fiscal year 2020 first quarter",
        message_id: '2',
        date: '25 Apr 2024'
      },
      {
        user: 'system',
        message: "The revenue of McKesson Corporation for fiscal year 2018 first quarter was $52.6 billion, while the revenue of McKesson Corporation for fiscal year 2020 first quarter was $55.7 billion, representing an increase of 6.2%.",
        message_id: '3',
        date: '25 Apr 2024'
      },

    ]

    this.messages = msgs
  }

  submit() {
    const msg: Message = {
      user: 'user',
      message: this.msgFormGrp.value.msg,
      message_id: '',
      date: ''
    }
    this.messages.push(msg)
    this.msgFormGrp.disable()
    this.msgFormGrp.reset()
    this.isLoading = true
    setTimeout(() => {
      this.isLoading = false
      this.msgFormGrp.enable()
      const msg: Message = {
        user: 'system',
        message: 'Some random text',
        message_id: '',
        date: ''
      }
      this.messages.push(msg)
    }, 3000);
  }


}

export interface Message {
  user: string;
  message: string;
  message_id: string;
  date: string
}
