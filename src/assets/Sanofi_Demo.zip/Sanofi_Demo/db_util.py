import pandas as pd 

def connectToDB():
    print("Connection established")
    return True

def retrieve_from_db(tableName):
    filepath = 'data/' + tableName + ".csv"
    df = pd.read_csv(filepath)
    return df

# def cosine_match_sales_prod_dist(uuid):
#     filepath = 'data/Cosine_Product_Sample_Dist_Sales.csv'
#     df = pd.read_csv(filepath)
#     print(df)
#     print("Successfully matched cosines")
#     return uui