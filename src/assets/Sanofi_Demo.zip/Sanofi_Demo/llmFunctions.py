import pandas as pd

def refineThroughLLM(df):
    filepath = 'data/LLM_Product_Sample_Dist_Sales.csv'
    df = pd.read_csv(filepath)
    # print(uuid)
    # print(df)
    # print("Successfully matched cosines")
    return df