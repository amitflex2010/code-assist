import pandas as pd

def similarity_search(id,src_df,tgt_df):
    filepath = 'data/Cosine_Product_Sample_Dist_Sales.csv'
    df = pd.read_csv(filepath)
    # print(uuid)
    # print(df)
    # print("Successfully matched cosines")
    return df



def cosine_match_sales_prod_data(uuid):
    pass

def cosine_match_prod_dist_data(uuid):
    pass